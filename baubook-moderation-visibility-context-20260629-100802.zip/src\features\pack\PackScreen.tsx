import { useCallback, useEffect, useMemo, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { baubookImages } from '../../shared/assets/images';
import { useAuthAccount } from '../../shared/auth/AuthProvider';
import { addDogFriend, fetchDogFriends, MAX_DOG_FRIENDS, removeDogFriend, searchDogFriendCandidates, type DogFriendModel, type DogFriendSearchResult } from '../../shared/api/dogFriends';
import { blockProfile, reportBauBookContent, unblockProfile } from '../../shared/api/userSafety';
import { AppButton } from '../../shared/components/AppButton';
import { AppCard } from '../../shared/components/AppCard';
import { IconBubble } from '../../shared/components/IconBubble';
import { Screen } from '../../shared/components/Screen';
import { Tag } from '../../shared/components/Tag';
import { colors, radius, spacing, typography } from '../../shared/theme/theme';
import type { TabKey } from '../../shared/types/domain';

interface PackScreenProps {
  onNavigate: (tab: TabKey) => void;
}

type LoadStatus = 'idle' | 'loading' | 'ready' | 'error';

function avatarSource(uri: string | null | undefined) {
  return uri ? { uri } : baubookImages.avatar;
}

function compactLocation(label: string | null | undefined): string | null {
  const clean = label?.trim();
  return clean?.length ? clean : null;
}

function FriendActionGlyph({ type }: { type: 'add' | 'remove' }) {
  const colorStyle = type === 'add' ? styles.friendAddGlyphBar : styles.friendRemoveGlyphBar;

  return (
    <View style={styles.friendIconGlyph} pointerEvents="none">
      <View style={[styles.friendIconGlyphHorizontal, colorStyle]} />
      {type === 'add' ? <View style={[styles.friendIconGlyphVertical, colorStyle]} /> : null}
    </View>
  );
}

export function PackScreen({ onNavigate }: PackScreenProps) {
  const auth = useAuthAccount();
  const [selectedDogId, setSelectedDogId] = useState<string | null>(auth.dogs[0]?.id ?? null);
  const [friends, setFriends] = useState<DogFriendModel[]>([]);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<DogFriendSearchResult[]>([]);
  const [status, setStatus] = useState<LoadStatus>('idle');
  const [searchStatus, setSearchStatus] = useState<LoadStatus>('idle');
  const [message, setMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | undefined>();

  const selectedDog = useMemo(() => auth.dogs.find((dog) => dog.id === selectedDogId) ?? auth.dogs[0] ?? null, [auth.dogs, selectedDogId]);
  const profileReady = auth.isSignedIn && Boolean(auth.profile);
  const dogReady = auth.dogs.length > 0;
  const friendLimitReached = friends.length >= MAX_DOG_FRIENDS;
  const cleanQuery = query.trim();
  const canSearch = Boolean(profileReady && selectedDog && cleanQuery.length >= 2 && searchStatus !== 'loading');

  useEffect(() => {
    if (!auth.dogs.length) {
      setSelectedDogId(null);
      return;
    }

    if (!selectedDogId || !auth.dogs.some((dog) => dog.id === selectedDogId)) {
      setSelectedDogId(auth.dogs[0].id);
    }
  }, [auth.dogs, selectedDogId]);

  useEffect(() => {
    if (!message && !errorMessage) {
      return;
    }

    const timeoutId = setTimeout(() => {
      setMessage('');
      setErrorMessage(undefined);
    }, 5000);

    return () => clearTimeout(timeoutId);
  }, [message, errorMessage]);

  const loadFriends = useCallback(async () => {
    if (!selectedDog) {
      setFriends([]);
      setStatus('idle');
      return;
    }

    try {
      setStatus('loading');
      const nextFriends = await fetchDogFriends(selectedDog.id);
      setFriends(nextFriends);
      setStatus('ready');
      setErrorMessage(undefined);
    }
    catch (error) {
      setStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'BauBook friends non caricati.');
    }
  }, [selectedDog]);

  useEffect(() => {
    void loadFriends();
  }, [loadFriends]);

  const handleSearch = useCallback(async () => {
    if (!selectedDog || !canSearch) {
      if (cleanQuery.length > 0 && cleanQuery.length < 2) {
        setMessage('Scrivi almeno 2 caratteri per cercare.');
      }
      return;
    }

    try {
      setSearchStatus('loading');
      setMessage('');
      const nextResults = await searchDogFriendCandidates({ dogId: selectedDog.id, query: cleanQuery, limit: 8 });
      setResults(nextResults);
      setSearchStatus('ready');
      setErrorMessage(undefined);
      setMessage(nextResults.length ? `${nextResults.length} risultato/i trovati.` : 'Nessun BauBook friend trovato con questa ricerca.');
    }
    catch (error) {
      setSearchStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Ricerca BauBook friends non riuscita.');
    }
  }, [canSearch, cleanQuery, selectedDog]);

  const handleAdd = useCallback(async (candidate: DogFriendSearchResult) => {
    if (!auth.profile || !selectedDog) {
      setErrorMessage('Prima completa profilo utente e profilo 🐾.');
      return;
    }

    if (friendLimitReached) {
      setMessage(`Hai gia ${MAX_DOG_FRIENDS} BauBook friends: rimuovine uno per aggiungerne un altro.`);
      return;
    }

    try {
      setSearchStatus('loading');
      await addDogFriend({
        ownerId: auth.profile.id,
        dogId: selectedDog.id,
        friendOwnerId: candidate.ownerId,
        friendDogId: candidate.dogId,
      });
      setResults((current) => current.filter((item) => item.dogId !== candidate.dogId));
      setMessage(`${candidate.dogName} aggiunto ai BauBook friends.`);
      setErrorMessage(undefined);
      await loadFriends();
      setSearchStatus('ready');
    }
    catch (error) {
      setSearchStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Aggiunta BauBook friend non riuscita.');
    }
  }, [auth.profile, friendLimitReached, loadFriends, selectedDog]);

  const handleRemove = useCallback(async (friend: DogFriendModel) => {
    try {
      setStatus('loading');
      await removeDogFriend(friend.id);
      setFriends((current) => current.filter((item) => item.id !== friend.id));
      setMessage(`${friend.friendDogName} rimosso dai BauBook friends.`);
      setErrorMessage(undefined);
      setStatus('ready');
    }
    catch (error) {
      setStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Rimozione BauBook friend non riuscita.');
    }
  }, []);

  const handleReportFriend = useCallback(async (friend: DogFriendModel) => {
    try {
      setStatus('loading');
      const result = await reportBauBookContent(
        'dog_profile',
        friend.friendDogId,
        'abuse',
        `Segnalazione abuso sul profilo 🐾 ${friend.friendDogName}.`,
      );
      setFriends((current) => current.map((item) => item.friendDogId === friend.friendDogId ? { ...item, hasReportedByMe: true } : item));
      setResults((current) => current.map((item) => item.dogId === friend.friendDogId ? { ...item, hasReportedByMe: true } : item));
      setMessage(result.alreadyReported ? 'Avevi già segnalato questo profilo.' : 'Segnalazione inviata alla moderazione.');
      setErrorMessage(undefined);
      setStatus('ready');
    } catch (error) {
      setStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Segnalazione profilo non riuscita.');
    }
  }, []);

  const handleBlockFriend = useCallback(async (friend: DogFriendModel) => {
    try {
      setStatus('loading');
      await blockProfile(friend.friendOwnerId);
      setFriends((current) => current.map((item) => item.friendOwnerId === friend.friendOwnerId ? { ...item, isBlockedByMe: true } : item));
      setResults((current) => current.map((item) => item.ownerId === friend.friendOwnerId ? { ...item, isBlockedByMe: true } : item));
      setMessage(`${friend.friendDogName} è bloccato. Resta visibile nel Branco e puoi sbloccarlo quando vuoi.`);
      setErrorMessage(undefined);
      setStatus('ready');
    } catch (error) {
      setStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Blocco profilo non riuscito.');
    }
  }, []);

  const handleUnblockFriend = useCallback(async (friend: DogFriendModel) => {
    try {
      setStatus('loading');
      await unblockProfile(friend.friendOwnerId);
      setFriends((current) => current.map((item) => item.friendOwnerId === friend.friendOwnerId ? { ...item, isBlockedByMe: false } : item));
      setResults((current) => current.map((item) => item.ownerId === friend.friendOwnerId ? { ...item, isBlockedByMe: false } : item));
      setMessage(`${friend.friendDogName} sbloccato.`);
      setErrorMessage(undefined);
      setStatus('ready');
    } catch (error) {
      setStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Sblocco profilo non riuscito.');
    }
  }, []);


  const handleBlockCandidate = useCallback(async (candidate: DogFriendSearchResult) => {
    try {
      setSearchStatus('loading');
      await blockProfile(candidate.ownerId);
      setResults((current) => current.map((item) => item.ownerId === candidate.ownerId ? { ...item, isBlockedByMe: true } : item));
      setFriends((current) => current.map((item) => item.friendOwnerId === candidate.ownerId ? { ...item, isBlockedByMe: true } : item));
      setMessage(`${candidate.dogName} è bloccato. Resta visibile nella ricerca e puoi sbloccarlo quando vuoi.`);
      setErrorMessage(undefined);
      setSearchStatus('ready');
    } catch (error) {
      setSearchStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Blocco profilo non riuscito.');
    }
  }, []);

  const handleUnblockCandidate = useCallback(async (candidate: DogFriendSearchResult) => {
    try {
      setSearchStatus('loading');
      await unblockProfile(candidate.ownerId);
      setResults((current) => current.map((item) => item.ownerId === candidate.ownerId ? { ...item, isBlockedByMe: false } : item));
      setFriends((current) => current.map((item) => item.friendOwnerId === candidate.ownerId ? { ...item, isBlockedByMe: false } : item));
      setMessage(`${candidate.dogName} sbloccato.`);
      setErrorMessage(undefined);
      setSearchStatus('ready');
    } catch (error) {
      setSearchStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Sblocco profilo non riuscito.');
    }
  }, []);


  return (
    <Screen>
      <AppCard tone="teal">
        <View style={styles.heroRow}>
          <View style={styles.heroImageFrame}>
            <Image source={baubookImages.pack.dogFriends} style={styles.heroPackImage} />
          </View>
          <View style={styles.heroCopy}>
            <Text style={styles.eyebrow}>Branco BauBook</Text>
            <Text style={styles.title}>{selectedDog ? `Amici del ❤️` : 'Il branco BauBook'}</Text>
            <Text style={styles.bodyText}>Aggiungi fino a {MAX_DOG_FRIENDS} amici BauBook cercando per nome utente o 🐕.</Text>
          </View>
        </View>
        <Text style={styles.heroSafetyText}>Puoi segnalare un comportamento inappropriato o bloccare un utente non gradito.</Text>
      </AppCard>

      {!profileReady || !dogReady ? (
        <AppCard elevated={false}>
          <View style={styles.sectionTitleRow}>
            <IconBubble source={baubookImages.icons.dogProfile} tone="warm" />
            <View style={styles.flexOne}>
              <Text style={styles.cardTitle}>Manca qualcosa!</Text>
              <Text style={styles.bodyText}>Per trovare amici BauBook serve un account registrato e almeno un profilo 🐶.</Text>
            </View>
          </View>
          <View style={styles.quickActions}>
            <AppButton label="Setup" variant="secondary" icon={baubookImages.icons.profileGear} onPress={() => onNavigate('profile')} />
            <AppButton label="Io sono" icon={baubookImages.icons.dogProfile} onPress={() => onNavigate('dog')} />
          </View>
        </AppCard>
      ) : null}

      {dogReady ? (
        <AppCard elevated={false}>
          <View style={styles.sectionTitleRow}>
            <IconBubble source={baubookImages.icons.friends} tone="teal" />
            <View style={styles.flexOne}>
              <Text style={styles.cardTitle}>Compagni di scodinzolata</Text>
              <Text style={styles.bodyText}>Cerca e gestisci la tua lista amici. Max {MAX_DOG_FRIENDS}.</Text>
            </View>
            <Tag label={`${friends.length}/${MAX_DOG_FRIENDS}`} tone={friendLimitReached ? 'orange' : 'green'} />
          </View>

          {auth.dogs.length > 1 ? (
            <View style={styles.dogSelector}>
              {auth.dogs.map((dog) => {
                const selected = dog.id === selectedDog?.id;
                return (
                  <Pressable key={dog.id} onPress={() => setSelectedDogId(dog.id)} style={({ pressed }) => [styles.dogChip, selected && styles.dogChipSelected, pressed && styles.pressed]}>
                    <Image source={avatarSource(dog.avatarUrl)} style={styles.chipAvatar} />
                    <Text style={[styles.dogChipText, selected && styles.dogChipTextSelected]}>{dog.name}</Text>
                  </Pressable>
                );
              })}
            </View>
          ) : null}

          <View style={styles.searchBox}>
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="Cerca per nome utente o 🐕"
              placeholderTextColor={colors.muted}
              autoCapitalize="words"
              autoCorrect={false}
              returnKeyType="search"
              onSubmitEditing={() => void handleSearch()}
              style={styles.input}
            />
            <AppButton label={searchStatus === 'loading' ? 'Cerco...' : 'Cerca'} icon={baubookImages.icons.search} onPress={handleSearch} disabled={!canSearch} />
          </View>

          {friendLimitReached ? (
            <Text style={styles.limitText}>Lista piena: rimuovi un amico per aggiungerne uno nuovo.</Text>
          ) : null}

          {results.length ? (
            <View style={styles.resultList}>
              {results.map((result) => {
                const cityLabel = compactLocation(result.cityLabel);
                return (
                  <View key={result.dogId} style={styles.friendCard}>
                    <View style={styles.friendHeaderLine}>
                      <View style={styles.friendHeaderLeft}>
                        <Text style={styles.friendHeaderName} numberOfLines={1}>🐾 {result.dogName}</Text>
                        {result.isBlockedByMe ? (
                          <Pressable
                            onPress={() => void handleUnblockCandidate(result)}
                            disabled={searchStatus === 'loading'}
                            accessibilityRole="button"
                            accessibilityLabel={`Sblocca ${result.dogName}`}
                            style={({ pressed }) => [styles.blockedInlineAction, searchStatus === 'loading' ? styles.friendIconActionDisabled : null, pressed ? styles.pressed : null]}
                          >
                            <Text style={styles.blockedInlineActionText} numberOfLines={1}>Sblocca utente 🔓</Text>
                          </Pressable>
                        ) : null}
                      </View>
                      <View style={styles.friendHeaderRight}>
                        {cityLabel ? <Text style={styles.friendHeaderLocation} numberOfLines={1}>📍 {cityLabel}</Text> : null}
                      </View>
                    </View>
                    {result.isBlockedByMe ? (
                      <View style={styles.blockedNotice}>
                        <Text style={styles.blockedNoticeText}>⛔ Utente bloccato: resta visibile nella ricerca e puoi sbloccarlo quando vuoi.</Text>
                      </View>
                    ) : null}
                    <View style={styles.friendBodyRow}>
                      <Image source={avatarSource(result.avatarUrl)} style={[styles.friendAvatar, result.isBlockedByMe ? styles.friendAvatarBlocked : null]} />
                      <View style={styles.friendCopy}>
                        <Text style={styles.friendOwnerLabel} numberOfLines={1}>👤 {result.ownerDisplayName}</Text>
                        {result.tags.length ? (
                          <View style={styles.tagsRow}>
                            {result.tags.slice(0, 3).map((tag) => <Tag key={tag} label={tag} tone="teal" />)}
                          </View>
                        ) : null}
                      </View>
                      <Pressable
                        onPress={() => void handleAdd(result)}
                        disabled={friendLimitReached || searchStatus === 'loading' || result.isBlockedByMe}
                        accessibilityRole="button"
                        accessibilityLabel={result.isBlockedByMe ? `${result.dogName} è bloccato` : `Aggiungi ${result.dogName}`}
                        style={({ pressed }) => [
                          styles.friendIconAction,
                          styles.friendAddAction,
                          (friendLimitReached || searchStatus === 'loading' || result.isBlockedByMe) ? styles.friendIconActionDisabled : null,
                          pressed ? styles.pressed : null,
                        ]}
                      >
                        <FriendActionGlyph type="add" />
                      </Pressable>
                    </View>
                    {!result.isBlockedByMe ? (
                      <View style={[styles.safetyActionRow, styles.safetyActionRowCenter]}>
                        <AppButton
                          label="Blocca utente"
                          size="compact"
                          variant="secondary"
                          disabled={searchStatus === 'loading'}
                          onPress={() => void handleBlockCandidate(result)}
                        />
                      </View>
                    ) : null}
                  </View>
                );
              })}
            </View>
          ) : null}
        </AppCard>
      ) : null}

      {dogReady ? (
        <AppCard tone="warm">
          <View style={styles.sectionTitleRow}>
            <IconBubble source={baubookImages.icons.favorites} tone="warm" />
            <View style={styles.flexOne}>

              <Text style={[styles.bodyText, status !== 'loading' && friends.length ? styles.savedPackText : null]}>{status === 'loading' ? 'Caricamento lista...' : friends.length ? 'Il mio piccolo branco salvato su BauBook!' : 'Nessun amico BauBook ancora aggiunto. 🥺'}</Text>
            </View>
          </View>

          <View style={styles.friendList}>
            {friends.map((friend) => {
              const cityLabel = compactLocation(friend.friendCityLabel);
              return (
                <View key={friend.id} style={[styles.friendCard, friend.isBlockedByMe ? styles.friendCardBlocked : null]}>
                  <View style={styles.friendHeaderLine}>
                    <View style={styles.friendHeaderLeft}>
                      <Text style={styles.friendHeaderName} numberOfLines={1}>🐾 {friend.friendDogName}</Text>
                      {friend.isBlockedByMe ? (
                        <Pressable
                          onPress={() => void handleUnblockFriend(friend)}
                          disabled={status === 'loading'}
                          accessibilityRole="button"
                          accessibilityLabel={`Sblocca ${friend.friendDogName}`}
                          style={({ pressed }) => [styles.blockedInlineAction, status === 'loading' ? styles.friendIconActionDisabled : null, pressed ? styles.pressed : null]}
                        >
                          <Text style={styles.blockedInlineActionText}>Sblocca utente 🔓</Text>
                        </Pressable>
                      ) : null}
                    </View>
                    <View style={styles.friendHeaderRight}>
                      {cityLabel ? <Text style={styles.friendHeaderLocation} numberOfLines={1}>📍 {cityLabel}</Text> : null}
                    </View>
                  </View>
                  {friend.isBlockedByMe ? (
                    <View style={styles.blockedNotice}>
                      <Text style={styles.blockedNoticeText}>⛔ Utente bloccato: resta nel Branco, puoi sbloccarlo o rimuoverlo.</Text>
                    </View>
                  ) : null}
                  <View style={styles.friendBodyRow}>
                    <Image source={avatarSource(friend.friendDogAvatarUrl)} style={[styles.friendAvatar, friend.isBlockedByMe ? styles.friendAvatarBlocked : null]} />
                    <View style={styles.friendCopy}>
                      <Text style={styles.friendOwnerLabel} numberOfLines={1}>👤 {friend.friendOwnerDisplayName}</Text>
                      {friend.friendTags.length ? (
                        <View style={styles.tagsRow}>
                          {friend.friendTags.slice(0, 3).map((tag) => <Tag key={tag} label={tag} tone="teal" />)}
                        </View>
                      ) : null}
                    </View>
                    <Pressable
                      onPress={() => void handleRemove(friend)}
                      disabled={status === 'loading'}
                      accessibilityRole="button"
                      accessibilityLabel={`Rimuovi ${friend.friendDogName}`}
                      style={({ pressed }) => [
                        styles.friendIconAction,
                        styles.friendRemoveAction,
                        status === 'loading' ? styles.friendIconActionDisabled : null,
                        pressed ? styles.pressed : null,
                      ]}
                    >
                      <FriendActionGlyph type="remove" />
                    </Pressable>
                  </View>
                  {!friend.isBlockedByMe ? (
                    <View style={styles.safetyActionRow}>
                      <AppButton
                        label={friend.hasReportedByMe ? 'Segnalato🚩' : 'Segnala🚨'}
                        size="compact"
                        variant="ghost"
                        disabled={status === 'loading' || friend.hasReportedByMe}
                        onPress={() => void handleReportFriend(friend)}
                      />
                      <AppButton
                        label="Blocca utente"
                        size="compact"
                        variant="secondary"
                        disabled={status === 'loading'}
                        onPress={() => void handleBlockFriend(friend)}
                      />
                    </View>
                  ) : null}
                </View>
              );
            })}
          </View>
        </AppCard>
      ) : null}

      {message ? <Text style={styles.infoText}>{message}</Text> : null}
      {errorMessage ? <Text style={styles.errorText}>{errorMessage}</Text> : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  heroRow: {
    flexDirection: 'row',
    gap: spacing.md,
    alignItems: 'center',
  },
  heroImageFrame: {
    width: 110,
    height: 110,
    borderRadius: 32,
    backgroundColor: 'rgba(255,255,255,0.78)',
    borderWidth: 0,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  heroPackImage: {
    width: 112,
    height: 112,
    resizeMode: 'cover',
  },
  heroCopy: {
    flex: 1,
    gap: 4,
  },
  eyebrow: {
    color: colors.primaryDark,
    fontSize: typography.tiny,
    fontWeight: '900',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  title: {
    color: colors.ink,
    fontSize: typography.h1,
    fontWeight: '900',
  },
  bodyText: {
    color: colors.muted,
    fontSize: typography.body,
    lineHeight: 22,
  },
  savedPackText: {
    paddingTop: 10,
  },
  bodyTextStrong: {
    color: colors.primaryDark,
    fontWeight: '900',
  },
  heroSafetyText: {
    marginTop: spacing.sm,
    color: colors.primaryDark,
    fontSize: typography.small,
    lineHeight: 19,
    fontWeight: '900',
  },
  sectionTitleRow: {
    flexDirection: 'row',
    gap: spacing.md,
    alignItems: 'flex-start',
  },
  flexOne: {
    flex: 1,
    gap: 4,
  },
  cardTitle: {
    color: colors.ink,
    fontSize: typography.h2,
    fontWeight: '900',
  },
  quickActions: {
    marginTop: spacing.lg,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: spacing.sm,
  },
  dogSelector: {
    marginTop: spacing.lg,
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  dogChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  dogChipSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.tealSoft,
  },
  chipAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    resizeMode: 'cover',
  },
  dogChipText: {
    color: colors.text,
    fontSize: typography.small,
    fontWeight: '900',
  },
  dogChipTextSelected: {
    color: colors.primaryDark,
  },
  searchBox: {
    marginTop: spacing.lg,
    gap: spacing.sm,
  },
  input: {
    minHeight: 48,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.md,
    color: colors.ink,
    fontSize: typography.body,
    fontWeight: '700',
  },
  resultList: {
    marginTop: spacing.lg,
    gap: spacing.sm,
  },
  friendList: {
    marginTop: spacing.lg,
    gap: spacing.sm,
  },
  friendCard: {
    gap: spacing.md,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'rgba(255,255,255,0.76)',
    padding: spacing.md,
  },
  friendCardBlocked: {
    borderColor: colors.warning,
    backgroundColor: colors.orangeSoft,
  },
  friendHeaderLine: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: spacing.sm,
  },
  friendHeaderLeft: {
    flex: 1,
    alignItems: 'flex-start',
    gap: spacing.xs,
  },
  friendHeaderName: {
    width: '100%',
    color: colors.ink,
    fontSize: typography.h3,
    fontWeight: '900',
  },
  friendHeaderRight: {
    maxWidth: '48%',
    alignItems: 'flex-end',
    gap: spacing.xs,
  },
  friendHeaderLocation: {
    flex: 1,
    color: colors.muted,
    fontSize: typography.small,
    lineHeight: 18,
    fontWeight: '900',
    textAlign: 'right',
  },
  friendBodyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  friendAvatar: {
    width: 54,
    height: 54,
    borderRadius: 27,
    resizeMode: 'cover',
  },
  friendAvatarBlocked: {
    opacity: 0.56,
  },
  friendCopy: {
    flex: 1,
    gap: 3,
  },
  friendOwnerLabel: {
    color: colors.muted,
    fontSize: typography.small,
    lineHeight: 18,
    fontWeight: '900',
  },
  friendIconAction: {
    width: 58,
    height: 58,
    borderRadius: 29,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    flexShrink: 0,
  },
  friendAddAction: {
    backgroundColor: colors.primary,
  },
  friendRemoveAction: {
    backgroundColor: colors.surface,
  },
  friendIconActionDisabled: {
    opacity: 0.45,
  },
  friendIconGlyph: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  friendIconGlyphHorizontal: {
    position: 'absolute',
    width: 28,
    height: 6,
    borderRadius: radius.pill,
  },
  friendIconGlyphVertical: {
    position: 'absolute',
    width: 6,
    height: 28,
    borderRadius: radius.pill,
  },
  friendAddGlyphBar: {
    backgroundColor: colors.surface,
  },
  friendRemoveGlyphBar: {
    backgroundColor: colors.primaryDark,
  },
  friendEmptyMeta: {
    color: colors.muted,
    fontSize: typography.small,
    lineHeight: 18,
    fontWeight: '800',
  },
  blockedInlineAction: {
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.orangeSoft,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  blockedInlineActionText: {
    color: colors.primaryDark,
    fontSize: typography.small,
    lineHeight: 18,
    fontWeight: '900',
  },
  blockedNotice: {
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.warning,
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  blockedNoticeText: {
    color: colors.primaryDark,
    fontSize: typography.small,
    lineHeight: 18,
    fontWeight: '900',
  },
  safetyActionRow: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.sm,
    marginTop: spacing.xs,
  },
  safetyActionRowCenter: {
    justifyContent: 'center',
  },
  tagsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.xs,
  },
  limitText: {
    marginTop: spacing.sm,
    color: colors.primaryDark,
    fontSize: typography.small,
    lineHeight: 18,
    fontWeight: '900',
  },
  infoText: {
    color: colors.primaryDark,
    fontSize: typography.small,
    lineHeight: 18,
    fontWeight: '900',
    textAlign: 'center',
  },
  errorText: {
    color: colors.danger,
    fontSize: typography.small,
    lineHeight: 18,
    fontWeight: '900',
    textAlign: 'center',
  },
  pressed: {
    opacity: 0.84,
    transform: [{ scale: 0.99 }],
  },
});
